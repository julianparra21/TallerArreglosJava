package ejercicios;

public class ejercicio17 {
	public static void main(String[]args) {
		 String nombre="Julian";
		 int documento=1096644178;
		 int edad=17;
		 String profesion="estudiante";
		 String telefono= "3205182013";
		 System.out.println("Datos ingresados: \n"+"Nombre completo: "+nombre+"\n Edad: "+edad+"\n Documento: "+documento+"\n Profesion: "+profesion+"\n telefono: "+telefono);
				 
	 }
}
