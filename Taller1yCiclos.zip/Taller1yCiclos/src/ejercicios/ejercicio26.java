package ejercicios;

public class ejercicio26 {
 public static void main(String[]args) {
	int n=5;
	int suma=n*(n+1)/2;
	System.out.println(suma);
}
 
}
