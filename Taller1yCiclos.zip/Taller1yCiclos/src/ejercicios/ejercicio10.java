package ejercicios;

public class ejercicio10 {
public static void main(String[]args) {
 double num1= 1.5;
 double num2= 4.5;
 double num3= 7.9;
 double resultado= num1+num2+num3;
 System.out.println("el resultado de la suma de los tres numeros es: "+resultado);
 
 
}
}
